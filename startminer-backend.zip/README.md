# StartMiner — Tap to Earn Free MTN Data

A tap-to-earn rewards site with **real email login (no passwords, just a 6-digit
code)** and a **real backend** that keeps track of every user's balance in a
local file on your computer (`data/db.json`) — no third-party database needed.

## How it works

1. User enters their email → gets a 6-digit code by email → enters it → logged in.
2. On the dashboard they tap a coin. Each tap adds a small random amount of MB
   (server-controlled, so it can't be faked from the browser).
3. Once a user's balance reaches **100MB**, the coin stops working — they must
   withdraw before it grows again.
4. When they withdraw, they enter the MTN phone number that should receive the
   data. The full request (their email, phone number, and amount) is emailed
   straight to **your** email address so you can pay them manually, and it's
   also saved permanently in `data/db.json` as a backup in case the email
   fails to send.

## ⚠️ Important: this needs a real server, GitHub Pages won't run it

GitHub Pages only hosts static files (HTML/CSS/JS) — it cannot run Node.js,
store data, or send emails. You can still keep this code in a GitHub repo,
but to actually use the site you need to run it as a server:

- **Easiest for now:** run it on your own computer with `npm start` (see
  below) while you test/use it.
- **To have it live all the time for real users:** deploy it to a free/cheap
  Node.js host such as Render, Railway, or Fly.io. The code doesn't need to
  change for that — you'd just set the same environment variables there.

## Setup

1. **Install Node.js** (v18 or newer) if you don't have it: https://nodejs.org

2. **Install dependencies** — open a terminal in this folder and run:
   ```
   npm install
   ```

3. **Configure your email settings.** Copy `.env.example` to a new file
   named `.env`, then open it and fill in:
   - `ADMIN_EMAIL` — the email address that should receive withdrawal
     requests (already set to yours: ezehdivinelove@gmail.com — change it if
     you want a different inbox).
   - `SMTP_USER` / `SMTP_PASS` — the email account the site sends *from*.
     Easiest option is Gmail with an **App Password** (not your normal
     Gmail password):
     1. Go to your Google Account → Security → turn on 2-Step Verification.
     2. Go to Security → App Passwords → create one for "Mail".
     3. Copy the 16-character password Google gives you into `SMTP_PASS`.
     4. Put the Gmail address itself in `SMTP_USER` and in `FROM_EMAIL`.
   - `JWT_SECRET` — change this to any long random string (used to keep
     people logged in securely).

4. **Start the server:**
   ```
   npm start
   ```
   You'll see `StartMiner backend running at http://localhost:3000`.

5. Open `http://localhost:3000` in your browser — that's the live site.

## Project structure

```
server.js      - the backend: routes for login, tapping, withdrawing
db.js          - local JSON-file database (data/db.json is created automatically)
mailer.js      - sends the login-code and withdrawal-request emails
public/        - the website itself (HTML/CSS/JS the user sees)
data/db.json   - created automatically; holds all users and withdrawal requests
.env           - your secret settings (you create this; never commit it)
```

## Adjusting the game

In your `.env` file you can tune:
- `CAP_MB` — the withdrawal threshold (default 100MB)
- `TAP_MIN_MB` / `TAP_MAX_MB` — how much MB each tap gives (default 0.3–0.8MB)
- `TAP_COOLDOWN_MS` — minimum time between taps, to stop tap-spamming

## Pushing to GitHub

The included `.gitignore` already excludes `node_modules/`, `.env`, and
`data/db.json` so you never accidentally publish your email password or
your users' data. Just run the usual:
```
git init
git add .
git commit -m "StartMiner tap-to-earn with email login"
git remote add origin <your-repo-url>
git push -u origin main
```
